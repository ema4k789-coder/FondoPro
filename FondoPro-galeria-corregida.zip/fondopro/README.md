# FondoPro — editor de imágenes

FondoPro es un editor web adaptable a escritorio y móvil. La edición manual se ejecuta localmente en el navegador; el borrador IA carga una librería y modelos remotos y necesita conexión a internet.

## Funciones
- Abrir imágenes locales compatibles con el navegador.
- Quitar fondo con IA.
- Retoque manual con pincel Borrar y Restaurar.
- Borrado de color por región conectada.
- Perfeccionar bordes: suavizar, contraer, expandir e invertir máscara.
- Fondos sólidos, transparente y degradados, con visibilidad independiente.
- Capas de imagen y texto; mostrar/ocultar, seleccionar texto, moverlo, editarlo, duplicarlo y cambiar el orden relativo de los textos.
- Recorte centrado por proporciones 1:1, 4:3, 3:4 y 16:9, con restablecimiento del encuadre original.
- Deshacer/rehacer hasta ocho estados recientes.
- Exportación con nombre personalizado a PNG o JPG.

## Ejecutar como web app
Sirve la carpeta por HTTP/HTTPS y abre `index.html` desde Chrome/Edge. La eliminación por IA necesita internet para descargar la librería y los modelos.

## Crear APK con Capacitor
Se incluye configuración inicial en `capacitor/`. En un equipo con Node.js LTS y Android Studio:
1. Copia `index.html`, `styles.css`, `app.js` y `manifest.json` a `capacitor/www/`.
2. Abre una terminal dentro de `capacitor/` y ejecuta `npm install`.
3. Ejecuta `npx cap add android` (solo la primera vez), `npx cap sync android` y `npx cap open android`.
4. En Android Studio, usa **Build > Build APK(s)**.

## Notas importantes
- La IA remota no garantiza una cancelación computacional inmediata: «Descartar resultado IA» evita aplicar el resultado cuando termina, pero el cálculo remoto/local iniciado por la librería puede continuar un tiempo.
- La app limita las imágenes cargadas a 40 MB y las reduce a un máximo de 2200 px por lado / 6 megapíxeles para controlar memoria.
- La orientación EXIF depende del decodificador del navegador. HEIC/HEIF puede no estar soportado; en ese caso, convierte a JPG o PNG.
- Antes de distribuir, ejecuta las pruebas de regresión enumeradas en `TODO_MEJORAS.md` en Chrome de escritorio y Android. La sintaxis y las referencias de HTML se validaron estáticamente, pero la ejecución interactiva no se pudo verificar en este entorno.
