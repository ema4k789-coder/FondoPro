Estos archivos web se mantienen sincronizados con la raíz del proyecto. El flujo de GitHub Actions vuelve a copiarlos antes de compilar el APK.
