# FondoPro — estado de edición

## Funciones incluidas en esta versión
- Capas separadas para fondo, imagen recortada, borde inteligente, dibujo y cada texto.
- Mostrar/ocultar y bloquear/desbloquear las capas desde el panel Capas.
- Reordenar capas con flechas arriba/abajo.
- Duplicar textos; cada texto conserva posición, tamaño, color, contorno y ángulo de forma independiente.
- Añadir trazos a una capa de dibujo separada del canal alfa de la máscara; color y tamaño configurables.
- Borrar la capa de dibujo sin afectar a la máscara de recorte.
- Borde inteligente configurable y con visibilidad propia.
- Deshacer/rehacer incluye el estado de dibujo, texto, máscara, fondo, borde y metadatos de capas.
- Texto puede añadirse y editarse sin cargar una imagen; conserva vista previa y tiradores de transformación.
- Zoom táctil y controles de zoom separados de las herramientas de dibujo.
- Exportación compuesta de las capas visibles.

## Límites conocidos
- La capa principal de imagen conserva su tamaño de lienzo; la transformación libre de imagen independiente (mover/escalar/rotar el objeto de imagen sin recortar el lienzo) no está implementada.
- La capa de dibujo se gestiona como una capa raster única; los trazos individuales no son objetos separados.
- La duplicación está disponible para textos; las capas estructurales Fondo/Imagen/Borde/Dibujo tienen controles de visibilidad, bloqueo, orden y eliminación lógica según su tipo.
- Validación estática de JavaScript, sincronización de archivos y estructura ZIP; no se ha realizado prueba interactiva completa en un teléfono Android real.
