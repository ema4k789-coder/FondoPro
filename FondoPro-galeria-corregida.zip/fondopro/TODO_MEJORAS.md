# FondoPro — auditoría y correcciones de esta iteración

## Corregido en el código
- El lienzo solo ejecuta el borrador manual cuando la pestaña **Pincel** está activa; hacer clic en el lienzo desde Texto/Fondo/Recorte ya no borra accidentalmente la máscara.
- El pincel sigue modificando el canal alfa de la máscara, que es la fuente usada por el renderizado antes y después de IA.
- Texto: color inicial oscuro y visible sobre fondos claros; el botón Añadir texto exige una imagen abierta y avisa si no la hay o si el campo está vacío.
- La selección y el movimiento de textos solo ocurren en la pestaña Texto; el arrastre actualiza la capa seleccionada.
- El lienzo tiene reglas explícitas para interacción táctil, evitando que gestos del navegador interfieran con el pincel en Android.
- Se sincronizaron `index.html`, `styles.css` y `app.js` con `capacitor/www/`.
- Validación estática: sintaxis JavaScript, IDs HTML únicos, selectores básicos y sincronización de recursos.

## Requiere prueba interactiva real
- Ejecutar la secuencia IA → Borrar → Restaurar → añadir/mover texto → cambiar fondo → recortar/restablecer → deshacer/rehacer → exportar.
- Probar en APK instalado en Android y en Chrome de escritorio. La validación estática no equivale a prueba real de dispositivo.
- Verificar descarga de los modelos IA con la conectividad del dispositivo y el origen HTTPS usado por el despliegue.

## Limitaciones conocidas
- El motor de eliminación de fondo se carga dinámicamente desde Internet; no funciona sin conexión si los recursos no están cacheados.
- La cancelación descarta el resultado, pero la librería externa puede continuar procesando hasta devolverlo.


## Mejoras de zoom y exportación (esta iteración)
- Se añadió zoom por gesto de dos dedos (pinch) con desplazamiento, más controles +/− y restablecer. El zoom es solo de visualización y no altera la resolución ni el contenido exportado.
- Se mejoró el botón Exportar para móviles, con altura táctil mayor y respeto del área segura superior de Android.
- En Capacitor se guarda una copia en Documentos/FondoPro y se intenta abrir el menú nativo para compartirla/guardarla en otra ubicación; en navegador se descarga y se indica revisar Descargas.
- Se añadieron las dependencias de Capacitor Filesystem y Share; `npx cap sync android` debe ejecutarse en el flujo de compilación.
- Validación estática únicamente; falta comprobar la ubicación final de guardado y el gesto pinch en un dispositivo Android real.


## Exportación directa a Galería
- Se añadió `@capacitor-community/media` para guardar imágenes en la biblioteca multimedia del móvil.
- En Android, FondoPro crea/usa un álbum visible llamado `FondoPro`; las imágenes se guardan en la galería y deben aparecer también en Recientes.
- El flujo de compilación debe copiar `node_modules/@capacitor-community/media/dist/plugin.js` a `capacitor/www/media-plugin.js` antes de `npx cap sync android`.
- Esta integración requiere compilar e instalar un APK nuevo; el APK antiguo seguirá usando el comportamiento anterior.
