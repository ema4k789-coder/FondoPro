# FondoPro — cambios de esta versión

- Vista de trabajo compacta: eliminados eslóganes, bloques de marketing y texto decorativo para dar más espacio al editor.
- Texto con vista previa en vivo al escribir; color y tamaño se reflejan antes de confirmar.
- Gestos táctiles: se espera a confirmar un toque antes de iniciar pincel/texto; al usar dos dedos se cancela la herramienta y solo se hace zoom/desplazamiento.
- Borde inteligente configurable por color y grosor, siguiendo la máscara alfa actual (por lo tanto sigue el recorte y el borrado de fondo).
- Los controles de borde están en la pestaña Recorte. Grosor 0 desactiva el borde.
- Aumentado el tamaño del botón Exportar y ajustado el encabezado al área segura del móvil.

Validación: sintaxis JavaScript y sincronización de assets; la interacción táctil debe probarse en un dispositivo Android real.
