# FondoPro — auditoría y lista de mejoras

## Implementado en esta versión
- [x] Conservar la imagen original como fuente para el borrado/restauración por máscara.
- [x] Componer la imagen y el fondo en el orden correcto; la transparencia no debe ser tapada por el fondo.
- [x] Ejecutar la IA varias veces sin multiplicar la transparencia progresivamente.
- [x] Conservar los retoques manuales que difieren de la última máscara IA al volver a ejecutar IA; la operación queda en el historial.
- [x] Comprobar la versión del documento antes de aceptar un resultado asíncrono de IA y bloquear la carga de otra imagen durante el proceso.
- [x] Añadir una acción para descartar el resultado de IA en curso. Nota: la librería remota no expone aquí una cancelación computacional garantizada; se descarta el resultado cuando vuelve.
- [x] Borrado por color conectado a la región tocada, no todos los píxeles similares de la imagen.
- [x] Contraer/expandir la máscara incluyendo los bordes del lienzo.
- [x] Limitar deshacer/rehacer a ocho estados y almacenar máscaras de historial en alfa de 1 byte por píxel.
- [x] Reutilizar el lienzo temporal de composición.
- [x] Limitar imágenes de entrada a 40 MB y reducir imágenes a un máximo de 2200 px por lado / 6 megapíxeles para las herramientas de edición.
- [x] Mensaje claro si el formato no se puede decodificar, incluyendo HEIC/HEIF.
- [x] Renombrar «Restablecer imagen» a «Restablecer máscara».
- [x] Añadir visibilidad independiente para fondo, imagen y texto.
- [x] Permitir seleccionar texto desde la lista, moverlo arrastrando, editarlo, duplicarlo y cambiar el orden relativo de textos.
- [x] Hacer que cada gesto de pincel sea una sola acción deshacible.
- [x] Hacer que los cambios de suavizado y color personalizado se registren como una operación deshacible por gesto.
- [x] Restablecer el encuadre original sin depender de los ocho estados del historial; se conserva la máscara de base y se superponen los retoques de la región recortada.
- [x] Permitir elegir el nombre de exportación, validar el blob generado y elegir PNG/JPG explícitamente.
- [x] Añadir etiqueta de estado accesible para lectores de pantalla.

## Validaciones ejecutadas
- [x] `node --check app.js` — sintaxis JavaScript válida.
- [x] Comprobación estática de HTML: sin IDs duplicados y sin referencias `$('#...')` a IDs inexistentes.
- [ ] Pruebas interactivas de navegador: no se pudieron ejecutar en este entorno por bloqueo del navegador automatizado.
- [ ] Pruebas manuales en Chrome de escritorio y Android/Capacitor.
- [ ] Validar la eliminación de fondo IA con conexión real, porque requiere descargar módulo y modelos remotos.

## Prueba de regresión antes de distribuir
1. Abrir un PNG con transparencia y un JPG opaco.
2. Aplicar IA; borrar y restaurar manualmente; ejecutar IA otra vez y confirmar que se conservan los retoques manuales.
3. Contraer, expandir, invertir y suavizar la máscara; deshacer/rehacer cada acción.
4. Borrar una región de color y verificar que otras zonas aisladas del mismo color no se borran.
5. Cambiar el fondo, ocultar/mostrar fondo e imagen y verificar que las capas se recuperan.
6. Añadir dos textos, seleccionar desde la lista, mover, editar, duplicar, reordenar, ocultar y eliminar.
7. Recortar dos veces, restablecer el encuadre original, y comprobar que se conserva el retoque de la zona visible.
8. Deshacer y rehacer alrededor de recortes y cambios de fondo.
9. Exportar PNG con transparencia y JPG con fondo; comprobar nombres, dimensiones y resultado.
10. Repetir en imágenes grandes y Android para detectar bloqueos o consumo excesivo de memoria.

> Alcance: se completaron las mejoras de código que pueden verificarse estáticamente. No se declara certificación de funcionamiento real hasta completar las pruebas de navegador y dispositivo indicadas arriba.
