Copia aquí index.html, styles.css, app.js y manifest.json antes de ejecutar npx cap add android.
