const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const canvas=$('#canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true}),mask=document.createElement('canvas'),mctx=mask.getContext('2d'),original=document.createElement('canvas'),octx=original.getContext('2d');
let loaded=false,bg='#ffffff',gradient='',mode='erase',brush=36,softness=0,drawing=false,last=null,textLayers=[],history=[],redoHistory=[],cropRatio=1,scaleX=1,scaleY=1,tolerance=35;
let imageLayer={name:'Imagen principal',visible:true};
canvas.style.touchAction='none';
function toast(msg){let t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function setStatus(s){$('#status').textContent=s}
function resize(w,h){canvas.width=w;canvas.height=h;mask.width=w;mask.height=h;original.width=w;original.height=h;$('#dimensions').textContent=`${w} × ${h} px`}
function captureState(){return {mask:mctx.getImageData(0,0,mask.width,mask.height),bg,gradient,textLayers:JSON.parse(JSON.stringify(textLayers)),w:canvas.width,h:canvas.height}}
function snapshot(){if(!loaded)return;history.push(captureState());if(history.length>20)history.shift();redoHistory=[]}
function restoreState(s){resize(s.w,s.h);mctx.putImageData(s.mask,0,0);bg=s.bg;gradient=s.gradient;textLayers=JSON.parse(JSON.stringify(s.textLayers));render()}
function fitCanvas(){const maxW=$('#stage').clientWidth-20,maxH=$('#stage').clientHeight-20;let k=Math.min(maxW/canvas.width,maxH/canvas.height,1);canvas.style.width=(canvas.width*k)+'px';canvas.style.height=(canvas.height*k)+'px';scaleX=canvas.width/(canvas.clientWidth||1);scaleY=canvas.height/(canvas.clientHeight||1)}
function drawBg(c){if(gradient){let g;if(gradient==='linear-gradient'){g=c.createLinearGradient(0,0,canvas.width,canvas.height);g.addColorStop(0,'#f9a8d4');g.addColorStop(.5,'#c4b5fd');g.addColorStop(1,'#93c5fd')}else if(gradient==='ocean'){g=c.createLinearGradient(0,0,canvas.width,canvas.height);g.addColorStop(0,'#67e8f9');g.addColorStop(1,'#4338ca')}else if(gradient==='candy'){g=c.createLinearGradient(0,0,canvas.width,canvas.height);g.addColorStop(0,'#fbcfe8');g.addColorStop(1,'#fda4af')}else{g=c.createLinearGradient(0,0,canvas.width,canvas.height);g.addColorStop(0,'#d9f99d');g.addColorStop(1,'#10b981')}c.fillStyle=g;c.fillRect(0,0,canvas.width,canvas.height)}else if(bg!=='transparent'){c.fillStyle=bg;c.fillRect(0,0,canvas.width,canvas.height)}}
function render(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  drawBg(ctx);
  if(loaded&&imageLayer.visible){
    const tmp=document.createElement('canvas');tmp.width=canvas.width;tmp.height=canvas.height;
    const tc=tmp.getContext('2d');
    tc.drawImage(original,0,0);
    tc.globalCompositeOperation='destination-in';
    tc.drawImage(mask,0,0);
    ctx.drawImage(tmp,0,0);
  }
  textLayers.forEach(t=>{if(t.visible===false)return;ctx.save();ctx.font=`700 ${t.size}px "DM Sans",sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=t.color;ctx.shadowColor='rgba(0,0,0,.22)';ctx.shadowBlur=3;ctx.fillText(t.text,t.x,t.y);ctx.restore()});
  updateLayers();fitCanvas();
}
function updateLayers(){let el=$('#layerList');el.innerHTML='';let arr=[];if(bg!=='transparent'||gradient)arr.push({name:'Fondo',type:'bg'});if(loaded)arr.push({name:imageLayer.name,type:'image'});textLayers.forEach((t,i)=>arr.push({name:'Texto: '+t.text,type:'text',i}));if(!arr.length)arr.push({name:'Lienzo transparente',type:'bg'});arr.forEach(a=>{let row=document.createElement('div');row.className='layer-item';row.innerHTML=`<span>${a.type==='bg'?'▧':a.type==='image'?'▣':'T'}</span><span></span><button title="Quitar capa">×</button>`;row.children[1].textContent=a.name;row.querySelector('button').onclick=()=>{snapshot();if(a.type==='bg'){bg='transparent';gradient=''}else if(a.type==='image')imageLayer.visible=false;else textLayers.splice(a.i,1);render()};el.appendChild(row)});$('#layerCount').textContent=arr.length+(arr.length===1?' elemento':' elementos')}
function loadFile(file){if(!file)return;if(!file.type.startsWith('image/')){toast('Elige un archivo de imagen.');return}let url=URL.createObjectURL(file),im=new Image();im.onload=()=>{let max=2200,k=Math.min(1,max/Math.max(im.width,im.height)),w=Math.round(im.width*k),h=Math.round(im.height*k);resize(w,h);octx.clearRect(0,0,w,h);octx.drawImage(im,0,0,w,h);mctx.clearRect(0,0,w,h);mctx.fillStyle='#fff';mctx.fillRect(0,0,w,h);loaded=true;imageLayer.visible=true;imageLayer.name=file.name;$('#empty').classList.add('hidden');history=[];redoHistory=[];textLayers=[];render();setStatus('Imagen cargada');toast('Imagen lista para editar');URL.revokeObjectURL(url)};im.onerror=()=>toast('No se pudo abrir esa imagen.');im.src=url}
$('#fileInput').onchange=e=>loadFile(e.target.files[0]);$('#fileInput2').onchange=e=>loadFile(e.target.files[0]);
$$('[data-tab]').forEach(b=>b.onclick=()=>{$$('.tab').forEach(x=>x.classList.toggle('active',x===b));$$('.tab-content').forEach(x=>x.classList.add('hidden'));$('#tab-'+b.dataset.tab).classList.remove('hidden')});
$$('[data-bg]').forEach(b=>b.onclick=()=>{bg=b.dataset.bg;gradient='';$('#bgColor').value=bg==='transparent'?'#ffffff':bg;$$('[data-bg]').forEach(x=>x.style.outline=x===b?'2px solid #7c3aed':'none')});
$('#applyBg').onclick=()=>{snapshot();bg=$('#bgColor').value;gradient=$('#gradient').value;render();toast('Fondo aplicado')};
$('#bgColor').oninput=()=>{bg=$('#bgColor').value;gradient='';render()};$('#gradient').onchange=()=>{gradient=$('#gradient').value;render()};
$('#brushSize').oninput=e=>{brush=+e.target.value;$('#brushOut').value=brush+' px'};
$('#softness').oninput=e=>{softness=+e.target.value;$('#softnessOut').value=softness};
$('#tolerance').oninput=e=>{tolerance=+e.target.value;$('#toleranceOut').value=tolerance};
$('#feather').oninput=e=>$('#featherOut').value=e.target.value+' px';
$$('[data-mode]').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;$$('[data-mode]').forEach(x=>x.classList.toggle('selected',x===b));$('#colorTools').classList.toggle('hidden',mode!=='color');setStatus(mode==='color'?'Toca el color que quieres quitar':'Modo '+(mode==='erase'?'borrar':'restaurar'))});
function pos(e){let r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
function stroke(a,b){
  // Brush dimensions are defined in on-screen CSS pixels, then mapped independently
  // to the image's native pixel grid. This avoids oversized/undersized strokes.
  const sx=canvas.width/Math.max(canvas.clientWidth,1), sy=canvas.height/Math.max(canvas.clientHeight,1);
  const ax=a.x, ay=a.y, bx=b.x, by=b.y;
  mctx.save();mctx.lineCap='round';mctx.lineJoin='round';
  mctx.lineWidth=Math.max(1,brush*(sx+sy)/2);
  mctx.shadowBlur=Math.max(0,softness*(sx+sy)/2);
  mctx.shadowColor='rgba(0,0,0,1)';
  mctx.strokeStyle='#fff';
  if(mode==='erase'){
    // Erase alpha from the editable mask; the source image remains untouched.
    mctx.globalCompositeOperation='destination-out';
    mctx.beginPath();mctx.moveTo(ax,ay);mctx.lineTo(bx,by);mctx.stroke();
  }else{
    // Restore the mask with a solid white stroke, preserving the source pixels.
    mctx.shadowBlur=0;mctx.globalCompositeOperation='source-over';mctx.strokeStyle='#fff';
    mctx.beginPath();mctx.moveTo(ax,ay);mctx.lineTo(bx,by);mctx.stroke();
  }
  mctx.restore();render();
}
function removeSimilarColor(point){if(!loaded)return;snapshot();const w=original.width,h=original.height,src=octx.getImageData(0,0,w,h),md=mctx.getImageData(0,0,w,h);const x=Math.max(0,Math.min(w-1,Math.floor(point.x))),y=Math.max(0,Math.min(h-1,Math.floor(point.y))),idx=(y*w+x)*4,r=src.data[idx],g=src.data[idx+1],b=src.data[idx+2],limit=tolerance*4;let removed=0;for(let i=0;i<src.data.length;i+=4){const dr=src.data[i]-r,dg=src.data[i+1]-g,db=src.data[i+2]-b;if(Math.sqrt(dr*dr+dg*dg+db*db)<=limit){md.data[i+3]=0;removed++}}mctx.putImageData(md,0,0);render();setStatus('Color eliminado');toast('Se quitaron '+removed.toLocaleString('es-AR')+' píxeles similares. Si borra de más, pulsa Deshacer.')}
canvas.addEventListener('pointerdown',e=>{if(!loaded)return;e.preventDefault();if(e.pointerType==='touch')canvas.style.touchAction='none';last=pos(e);if(mode==='color'){removeSimilarColor(last);last=null;return}drawing=true;canvas.setPointerCapture(e.pointerId);snapshot();stroke(last,{x:last.x+.01,y:last.y+.01})});
canvas.addEventListener('pointermove',e=>{if(!drawing||!last)return;e.preventDefault();let p=pos(e);stroke(last,p);last=p});
canvas.addEventListener('pointerup',e=>{if(drawing&&last){const p=pos(e);if(Math.hypot(p.x-last.x,p.y-last.y)>.01)stroke(last,p)}drawing=false;last=null});canvas.addEventListener('pointercancel',()=>{drawing=false;last=null});canvas.addEventListener('lostpointercapture',()=>{drawing=false;last=null});

function morphMask(direction){if(!loaded){toast('Primero abre una imagen.');return}snapshot();const w=mask.width,h=mask.height,im=mctx.getImageData(0,0,w,h),src=new Uint8ClampedArray(im.data),out=im.data;const alphaAt=(x,y)=>{if(x<0||y<0||x>=w||y>=h)return direction<0?0:255;return src[(y*w+x)*4+3]};for(let y=1;y<h-1;y++){for(let x=1;x<w-1;x++){let val=direction<0?255:0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const a=alphaAt(x+dx,y+dy);val=direction<0?Math.min(val,a):Math.max(val,a)}const i=(y*w+x)*4;out[i]=out[i+1]=out[i+2]=255;out[i+3]=val}}mctx.putImageData(im,0,0);render();toast(direction<0?'Borde contraído':'Borde expandido')}
$('#contractMask').onclick=()=>morphMask(-1);$('#expandMask').onclick=()=>morphMask(1);
$('#invertMask').onclick=()=>{if(!loaded){toast('Primero abre una imagen.');return}snapshot();const im=mctx.getImageData(0,0,mask.width,mask.height);for(let i=3;i<im.data.length;i+=4)im.data[i]=255-im.data[i];mctx.putImageData(im,0,0);render();toast('Selección invertida')};
$('#feather').onchange=()=>{const amount=+$('#feather').value;if(!loaded||amount===0)return;snapshot();const temp=document.createElement('canvas');temp.width=mask.width;temp.height=mask.height;const tc=temp.getContext('2d');tc.filter=`blur(${amount}px)`;tc.drawImage(mask,0,0);mctx.clearRect(0,0,mask.width,mask.height);mctx.drawImage(temp,0,0);render();toast('Borde suavizado')};
$('#resetMask').onclick=()=>{if(!loaded)return;snapshot();mctx.clearRect(0,0,mask.width,mask.height);mctx.fillStyle='#fff';mctx.fillRect(0,0,mask.width,mask.height);render();toast('Imagen restablecida')};
$('#addText').onclick=()=>{let v=$('#textValue').value.trim();if(!v){toast('Escribe un texto primero.');return}snapshot();textLayers.push({text:v,color:$('#textColor').value,size:+$('#textSize').value,x:canvas.width/2,y:canvas.height/2,visible:true});render();toast('Texto añadido')};
$$('[data-ratio]').forEach(b=>b.onclick=()=>{if(!loaded){toast('Primero abre una imagen.');return}snapshot();cropRatio=+b.dataset.ratio;let w=canvas.width,h=canvas.height;if(w/h>cropRatio)w=Math.round(h*cropRatio);else h=Math.round(w/cropRatio);let ox=Math.round((canvas.width-w)/2),oy=Math.round((canvas.height-h)/2);let oc=document.createElement('canvas');oc.width=w;oc.height=h;oc.getContext('2d').drawImage(original,ox,oy,w,h,0,0,w,h);let mc=document.createElement('canvas');mc.width=w;mc.height=h;mc.getContext('2d').drawImage(mask,ox,oy,w,h,0,0,w,h);resize(w,h);octx.drawImage(oc,0,0);mctx.drawImage(mc,0,0);textLayers=textLayers.map(t=>({...t,x:t.x-ox,y:t.y-oy}));render();toast('Proporción de recorte aplicada')});
$('#resetCrop').onclick=()=>{toast('Para recuperar el tamaño original, vuelve a cargar la imagen.')};
$('#fitBtn').onclick=fitCanvas;
$('#undoBtn').onclick=()=>{let s=history.pop();if(!s){toast('No hay cambios para deshacer.');return}redoHistory.push(captureState());restoreState(s);toast('Cambio deshecho')};
$('#redoBtn').onclick=()=>{let s=redoHistory.pop();if(!s){toast('No hay cambios para rehacer.');return}history.push(captureState());restoreState(s);toast('Cambio rehecho')};
async function autoRemove(){if(!loaded){toast('Primero abre una imagen.');return}let btn=$('#autoBtn');btn.disabled=true;btn.textContent='Procesando…';setStatus('Preparando IA');try{toast('Descargando el motor de IA (solo la primera vez)…');const mod=await import('https://esm.sh/@imgly/background-removal@1.5.5');const blob=await new Promise(resolve=>original.toBlob(resolve,'image/png'));const result=await mod.removeBackground(blob,{progress:(key,current,total)=>{setStatus('IA: '+Math.round(current/Math.max(total,1)*100)+'%')}});let url=URL.createObjectURL(result),im=new Image();await new Promise((res,rej)=>{im.onload=res;im.onerror=rej;im.src=url});snapshot();resize(im.width,im.height);octx.drawImage(im,0,0);mctx.clearRect(0,0,mask.width,mask.height);mctx.fillStyle='#fff';mctx.fillRect(0,0,mask.width,mask.height);bg='transparent';gradient='';render();setStatus('Fondo eliminado');toast('¡Fondo eliminado! Exporta como PNG para conservar transparencia.');URL.revokeObjectURL(url)}catch(err){console.error(err);toast('No se pudo iniciar la IA. Comprueba internet e inténtalo en Chrome; puede requerir memoria suficiente.');setStatus('IA no disponible')}finally{btn.disabled=false;btn.textContent='✦ Quitar fondo IA'}}
$('#autoBtn').onclick=autoRemove;
$('#exportBtn').onclick=()=>{if(!loaded&&!textLayers.length){toast('Primero abre una imagen.');return}let choice=confirm('Aceptar = PNG con transparencia. Cancelar = JPG con fondo blanco.');let type=choice?'image/png':'image/jpeg',ext=choice?'png':'jpg';let out=document.createElement('canvas');out.width=canvas.width;out.height=canvas.height;let c=out.getContext('2d');if(!choice){c.fillStyle='#fff';c.fillRect(0,0,out.width,out.height)}c.drawImage(canvas,0,0);out.toBlob(blob=>{if(!blob){toast('No se pudo exportar.');return}let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='fondopro-edicion.'+ext;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500);toast('Imagen exportada como '+ext.toUpperCase())},type,.94)};
window.addEventListener('resize',fitCanvas);
