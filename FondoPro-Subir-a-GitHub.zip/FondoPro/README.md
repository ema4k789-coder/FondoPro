# FondoPro — primera versión funcional

FondoPro es un prototipo de editor de imágenes con interfaz adaptable a móvil y escritorio.

## Funciones incluidas
- Abrir imágenes del dispositivo.
- Quitar fondo con IA usando `@imgly/background-removal` cargado desde esm.sh (requiere internet, navegador compatible y memoria suficiente).
- Retoque manual con pincel para borrar/restaurar zonas.
- Fondos sólidos, transparente y degradados.
- Añadir texto y capas sencillas para quitar elementos.
- Recorte por proporciones (1:1, 4:3, 3:4, 16:9).
- Deshacer cambios recientes.
- Exportar PNG o JPG.

## Probar rápido en Android
1. Descomprime `FondoPro.zip`.
2. La forma más simple de probarlo es servir la carpeta con un servidor web HTTPS y abrir el enlace en Chrome Android. La IA puede fallar si el navegador limita memoria.
3. En Chrome, menú ⋮ → **Añadir a pantalla principal** (si el sitio se sirve desde HTTPS, se abre como app web).

## Crear APK instalable con Capacitor
Se incluye una base de configuración de Capacitor en `capacitor/`. Para generar un APK necesitas un ordenador con Node.js y Android Studio:
1. Instala Node.js LTS y Android Studio.
2. Copia los archivos `index.html`, `styles.css`, `app.js` y `manifest.json` dentro de `capacitor/www/`.
3. Abre una terminal en `capacitor/` y ejecuta:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. En Android Studio, espera a que termine la sincronización y usa **Build > Build APK(s)**.
5. Instala el APK de prueba en tu teléfono.

### Nota sobre IA en Android
La eliminación automática importa un módulo remoto ESM y descarga modelos cuando se usa. Para un APK robusto de producción conviene integrar el modelo localmente o usar un backend/API de eliminación de fondo. El resto de herramientas funciona localmente en el navegador; las imágenes no se suben por el código de edición manual.

## Limitaciones de esta versión
Es un prototipo inicial, no una app publicada. Las capas son básicas; no incluye mover texto con gestos, proyectos guardados ni procesamiento por lotes. Recorte aplica una proporción centrada. Prueba con imágenes no sensibles antes de usarlo en un flujo de trabajo importante.


## APK gratis mediante GitHub Actions
Se incluye `.github/workflows/build-apk.yml`. Sube el archivo `FondoPro-Proyecto-Corregido.zip` a la raíz del repositorio de GitHub y crea el archivo `.github/workflows/build-apk.yml` con el flujo incluido en esta carpeta del proyecto. En **Actions → Build FondoPro APK → Run workflow**, inicia la compilación. El flujo evita la acción `setup-android` que estaba fallando y usa el SDK instalado en el runner de GitHub. Cuando termine correctamente, abre la ejecución y descarga **FondoPro-debug-APK** en la sección **Artifacts**. Es un APK de depuración para pruebas, no un lanzamiento firmado con una clave propia. GitHub Actions es gratuito para repositorios públicos en runners estándar, sujeto a las políticas y límites del servicio.


## Corrección del borrador manual
- Se simplificó el renderizado de la máscara para mantener la transparencia consistente.
- El borrador elimina alfa de la máscara y Restaurar vuelve a revelar los píxeles originales.
- Se ajustó el tamaño del pincel a la escala real del lienzo y se reforzó la captura de gestos táctiles.
